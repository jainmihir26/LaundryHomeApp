package com.example.stet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {
    EditText name_register;
    EditText email_register;
    EditText phone_number_register;
    EditText password_register;
    EditText confirm_password_register;
    TextView sign_in;
    FloatingActionButton button_register;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        final String url = "";

        name_register = findViewById(R.id.name_register);
        email_register = findViewById(R.id.email_register);
        phone_number_register = findViewById(R.id.phone_number_register);
        password_register = findViewById(R.id.password_register);
        confirm_password_register = findViewById(R.id.confirm_password_register);
        sign_in = findViewById(R.id.sign_in_register);
        button_register = findViewById(R.id.button_register);
        sign_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

        button_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String name = name_register.getText().toString().trim();
                final String email = email_register.getText().toString().trim();
                final String phone_number = phone_number_register.getText().toString().trim();
                final String password = password_register.getText().toString().trim();
                final String confirm_password = confirm_password_register.getText().toString().trim();

                StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        parseData(response);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }){
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String,String> params = new HashMap<String, String>();
                        params.put("name",name);
                        params.put("email",email);
                        params.put("phone_number",phone_number);
                        params.put("password",password);
                        return params;
                    }
                };

            }
        });





    }

    private void parseData(String response){

        try {
            JSONObject jsonObject = new JSONObject(response);

            if(jsonObject.getString("error").equals("false")){

            }else{

            }

        } catch (JSONException e) {
            e.printStackTrace();
        }


    }
}
